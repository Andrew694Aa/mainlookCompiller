#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import re
import time
import random

try:
    import readline
except ImportError:
    pass


class MyLangInterpreter:
    def __init__(self):
        self.vars = {}
        self.actions = {}
        self.action_labels = {}
        self.current_action = None
        self.ip = 0
        self.call_stack = []
        self.running = True
        self._jumped = False

    def load(self, filename):
        with open(filename, 'r', encoding='utf-8') as f:
            lines = [line.split('#', 1)[0].strip() for line in f if line.strip()]

        # Убираем BOM, если есть
        if lines and lines[0].startswith("\ufeff"):
            lines[0] = lines[0].replace("\ufeff", "")

        i = 0
        global_lines = []

        # Глобальные переменные до первого action
        while i < len(lines) and not lines[i].startswith('action'):
            global_lines.append(lines[i])
            i += 1

        self._execute_global(global_lines)

        # Чтение действий
        while i < len(lines):
            if lines[i].startswith('action'):
                # Более гибкое регулярное выражение
                match = re.match(r'action\s+(\w+)\s*\(\s*\)\s*$', lines[i])
                if not match:
                    raise SyntaxError(f"Invalid action declaration: {lines[i]}")

                action_name = match.group(1)
                i += 1
                body = []

                # Читаем тело action
                while i < len(lines) and not lines[i].startswith('action'):
                    body.append(lines[i])
                    i += 1

                self.actions[action_name] = body

                # Собираем LABEL'ы
                labels = {}
                for idx, line in enumerate(body):
                    stripped = line.strip()
                    if stripped.startswith('LABEL'):
                        parts = stripped.split()
                        if len(parts) == 2:
                            labels[parts[1]] = idx

                self.action_labels[action_name] = labels

            else:
                i += 1

    def _execute_global(self, lines):
        for line in lines:
            if not line:
                continue
            if '==' in line:
                left, right = line.split('==', 1)
                var_type, var_name = left.split()[:2]
                self.vars[var_name] = self._eval_expression(right.strip())
            else:
                var_type, var_name = line.split()[:2]
                self.vars[var_name] = self._default_value(var_type)

    def _default_value(self, var_type):
        if var_type == 'float':
            return 0.0
        if var_type == 'str':
            return ''
        if var_type == 'array':
            return []
        raise SyntaxError(f"Unknown type {var_type}")

    def _eval_expression(self, expr):
        expr = re.sub(r'\bAND\b', 'and', expr)
        expr = re.sub(r'\bOR\b', 'or', expr)
        expr = re.sub(r'\bNOT\b', 'not', expr)

        env = self.vars.copy()
        env.update({'True': True, 'False': False})

        try:
            safe_builtins = {"float": float, "int": int, "str": str}
            return eval(expr, {"__builtins__": safe_builtins}, env)
        except Exception as e:
            raise RuntimeError(f"Error in expression {expr}: {e}")

    def run(self, start_action='Start'):
        if start_action not in self.actions:
            print(f"Action {start_action} not found")
            return

        self.current_action = start_action
        self.ip = 0
        self.call_stack = []
        self.running = True

        while self.running:
            commands = self.actions[self.current_action]

            if self.ip >= len(commands):
                if self.call_stack:
                    self.current_action, self.ip = self.call_stack.pop()
                else:
                    self.running = False
                continue

            line = commands[self.ip].strip()
            if not line:
                self.ip += 1
                continue

            self._execute_command(line)

            if self.running and not self._jumped:
                self.ip += 1

            self._jumped = False

    def _jump_to_label(self, label):
        labels = self.action_labels.get(self.current_action, {})
        if label not in labels:
            raise RuntimeError(f"Label {label} not found in action {self.current_action}")
        self.ip = labels[label]
        self._jumped = True

    def _execute_command(self, line):
        # Объявление переменных
        if line.startswith(('float ', 'str ', 'array ')):
            parts = line.split()
            var_type, var_name = parts[:2]

            if '==' in line:
                left, right = line.split('==', 1)
                var_name = left.split()[1]
                self.vars[var_name] = self._eval_expression(right.strip())
            else:
                self.vars[var_name] = self._default_value(var_type)
            return

        # CLEAR_SCREEN
        if line == 'CLEAR_SCREEN':
            os.system('cls' if os.name == 'nt' else 'clear')
            return

        # IF ... GOTO ...
        if line.startswith('IF '):
            if ' GOTO ' not in line:
                raise SyntaxError(f"Invalid IF syntax: {line}")
            cond, label = line[3:].split(' GOTO ', 1)
            if self._eval_expression(cond.strip()):
                self._jump_to_label(label.strip())
            return

        # GOTO
        if line.startswith('GOTO '):
            self._jump_to_label(line[5:].strip())
            return

        # LABEL
        if line.startswith('LABEL '):
            return

        # SHOW_TEXT_COMM
        if line.startswith('SHOW_TEXT_COMM =='):
            text = line[len('SHOW_TEXT_COMM =='):].strip()
            text = re.sub(r'\{(\w+)\}', lambda m: str(self.vars.get(m.group(1), '')), text)

            if text.startswith('+'):
                text = text[1:].strip()

            try:
                result = eval(text, {"__builtins__": {}}, self.vars)
                print(result)
            except:
                print(text)
            return

        # WAIT_INPUT_COMM
        if line.startswith('WAIT_INPUT_COMM =='):
            var_name = line[len('WAIT_INPUT_COMM =='):].strip().strip('"')
            self.vars[var_name] = input()
            return

        # RANDOM
        if line.startswith('RANDOM '):
            rest, var = line[7:].split('==')
            min_val, max_val = rest.split(',')
            self.vars[var.strip()] = random.randint(
                int(self._eval_expression(min_val.strip())),
                int(self._eval_expression(max_val.strip()))
            )
            return

        # ARRAY_PUSH
        if line.startswith('ARRAY_PUSH '):
            arr, val = line[11:].split(',', 1)
            self.vars[arr.strip()].append(self._eval_expression(val.strip()))
            return

        # ARRAY_POP
        if line.startswith('ARRAY_POP '):
            self.vars[line[10:].strip()].pop()
            return

        # ARRAY_UNSHIFT
        if line.startswith('ARRAY_UNSHIFT '):
            arr, val = line[14:].split(',', 1)
            self.vars[arr.strip()].insert(0, self._eval_expression(val.strip()))
            return

        # ARRAY_GET
        if line.startswith('ARRAY_GET '):
            arr, idx, var = map(str.strip, line[10:].split(','))
            self.vars[var] = self.vars[arr][int(self._eval_expression(idx))]
            return

        # ARRAY_LEN
        if line.startswith('ARRAY_LEN '):
            arr, var = line[10:].split('==')
            self.vars[var.strip()] = len(self.vars[arr.strip()])
            return

        # start action ==
        if line.startswith('start action =='):
            action_name = line[len('start action =='):].strip()
            if action_name not in self.actions:
                raise RuntimeError(f"Action {action_name} not found")
            self.call_stack.append((self.current_action, self.ip + 1))
            self.current_action = action_name
            self.ip = 0
            self._jumped = True
            return

        # WAIT
        if line.startswith('WAIT '):
            match = re.match(r'WAIT\s+(\d+(?:\.\d+)?)(?:f)?\s*,\s*APP\.QUIT', line)
            if match:
                time.sleep(float(match.group(1)))
                self.running = False
                sys.exit(0)
            else:
                raise SyntaxError(f"Invalid WAIT syntax: {line}")

        # Присваивание
        if '==' in line:
            left, right = line.split('==', 1)
            self.vars[left.strip()] = self._eval_expression(right.strip())
            return

        raise SyntaxError(f"Unknown command: {line}")


def main():
    txt_filename = sys.argv[1] if len(sys.argv) > 1 else "config.txt"

    if not os.path.exists(txt_filename):
        print("Config file not found")
        sys.exit(1)

    with open(txt_filename, 'r', encoding='utf-8') as f:
        bgc_path = f.readline().strip()
        if not os.path.exists(bgc_path):
            print(f"File {bgc_path} not found")
            sys.exit(1)

    interpreter = MyLangInterpreter()
    interpreter.load(bgc_path)
    interpreter.run('Start')


if __name__ == '__main__':
    main()
